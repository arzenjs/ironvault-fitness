import Link from "next/link";
import { redirect } from "next/navigation";
import { ArrowUpRight, Clock3, History, Sparkles } from "lucide-react";
import AccountNav from "@/components/account/AccountNav";
import MembershipCard from "@/components/account/MembershipCard";
import PaymentHistory from "@/components/account/PaymentHistory";
import { PaymentBadge, MembershipBadge } from "@/components/account/Badges";
import { getSessionUser } from "@/lib/session";
import { connectDb } from "@/lib/db";
import { listUserMemberships, summariseMemberships } from "@/services/memberships";
import Payment from "@/models/Payment";
import { formatDate, formatINR, paymentStatusMeta } from "@/lib/format";
import { stateLabels } from "@/lib/membership-status";
import { getPlanById } from "@/config/membership-plans";

export const metadata = {
  title: "My account",
  robots: { index: false, follow: false },
};

export const dynamic = "force-dynamic";

export default async function AccountPage() {
  const user = await getSessionUser();
  if (!user) redirect(`/login?next=${encodeURIComponent("/account")}`);

  await connectDb();
  const [memberships, payments] = await Promise.all([
    listUserMemberships(user.id),
    Payment.find({ userId: user.id }).sort({ createdAt: -1 }).limit(25).lean(),
  ]);

  const summary = summariseMemberships(memberships);
  // Benefits are read from the central plan config, so they stay in sync.
  const currentPlan = getPlanById((summary.active || summary.queued[0])?.planId);
  const pending = payments.filter((payment) => ["created", "pending", "review"].includes(payment.status));

  return (
    <section className="pt-28 md:pt-32">
      <div className="shell pb-20">
        <div className="mb-5">
          <p className="eyebrow">Member dashboard</p>
          <h1 className="display mt-3 text-[clamp(2rem,4.6vw,3.2rem)]">
            Hello, <span className="text-signal">{user.name.split(" ")[0]}</span>
          </h1>
          <p className="mt-2 text-sm text-ash">Your membership, payments and renewal options in one place.</p>
        </div>

        <AccountNav user={user} />

        {pending.length ? (
          <div className="mt-6 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-amber-300/30 bg-amber-300/10 px-4 py-3">
            <p className="flex items-center gap-2 text-xs text-amber-100">
              <Clock3 size={14} aria-hidden="true" />
              {pending.length} payment{pending.length > 1 ? "s" : ""} awaiting confirmation. Your membership
              activates as soon as Razorpay confirms.
            </p>
            <Link
              href={`/checkout/result?ref=${pending[0]._id.toString()}`}
              className="text-xs font-medium text-amber-100 underline underline-offset-4 hover:text-white"
            >
              View status
            </Link>
          </div>
        ) : null}

        <div className="mt-6 grid gap-6 lg:grid-cols-[1.25fr_0.75fr]">
          {/* left column */}
          <div className="space-y-5">
            {summary.active ? (
              <MembershipCard membership={summary.active} derived={summary.active.derived} />
            ) : summary.queued.length ? (
              <MembershipCard
                membership={summary.queued[0]}
                derived={summary.queued[0].derived}
                title="Next membership (queued)"
              />
            ) : (
              <div className="rounded-[1.3rem] border border-dashed border-white/15 bg-coal p-6">
                <div className="flex items-start gap-4">
                  <Sparkles size={22} className="mt-0.5 shrink-0 text-signal" aria-hidden="true" />
                  <div>
                    <h2 className="text-lg font-semibold text-fog">
                      {summary.past.length ? "Your membership has expired" : "No active membership yet"}
                    </h2>
                    <p className="mt-2 max-w-md text-sm leading-relaxed text-ash">
                      {summary.past.length
                        ? "Your last plan has ended. Pick a new block and it starts from today — nothing is renewed automatically."
                        : "Choose a plan to get floor access, an orientation and your plan dates in this dashboard."}
                    </p>
                    <Link href="/memberships" className="btn btn-primary btn-sm mt-5">
                      View plans <ArrowUpRight size={14} aria-hidden="true" />
                    </Link>
                  </div>
                </div>
              </div>
            )}

            {summary.active && summary.queued.length ? (
              <div className="rounded-xl border border-sky-400/30 bg-sky-400/[0.07] p-4">
                <p className="flex items-center gap-2 text-xs font-medium text-sky-100">
                  <Clock3 size={13} aria-hidden="true" /> Queued membership
                </p>
                <p className="mt-1.5 text-sm text-fog">
                  {summary.queued[0].planName} starts {formatDate(summary.queued[0].startDate)} — the day after
                  your current plan ends, so no paid days are lost.
                </p>
              </div>
            ) : null}

            <div>
              <div className="mb-3 flex items-center justify-between gap-3">
                <h2 className="flex items-center gap-2 text-sm font-semibold text-fog">
                  <History size={15} className="text-signal" aria-hidden="true" /> Payment history
                </h2>
                <span className="font-mono text-[0.5625rem] uppercase tracking-[0.16em] text-ash">
                  {payments.length} record{payments.length === 1 ? "" : "s"}
                </span>
              </div>
              <PaymentHistory
                payments={payments.map((payment) => ({
                  id: payment._id.toString(),
                  planName: payment.planName,
                  amountPaise: payment.amountPaise,
                  status: payment.status,
                  createdAt: payment.createdAt,
                  razorpayPaymentId: payment.razorpayPaymentId,
                  razorpayOrderId: payment.razorpayOrderId,
                }))}
              />
            </div>
          </div>

          {/* right column */}
          <aside className="space-y-5">
            <div className="card p-5">
              <h2 className="eyebrow">Plan benefits</h2>
              {currentPlan ? (
                <>
                  <p className="mt-2 text-sm font-medium text-fog">{currentPlan.name}</p>
                  <ul className="mt-3 space-y-2 text-sm text-ash">
                    {currentPlan.benefits.map((benefit) => (
                      <li key={benefit} className="flex gap-2">
                        <span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-signal" aria-hidden="true" />
                        {benefit}
                      </li>
                    ))}
                  </ul>
                </>
              ) : (
                <p className="mt-3 text-sm text-ash">Benefits appear here once a membership is active.</p>
              )}
            </div>

            <div className="card p-5">
              <h2 className="eyebrow">Membership history</h2>
              {summary.all.length ? (
                <ul className="mt-3 space-y-3">
                  {summary.all
                    .slice()
                    .reverse()
                    .map((membership) => (
                      <li key={membership._id.toString()} className="border-b border-white/[0.07] pb-3 last:border-0 last:pb-0">
                        <div className="flex items-start justify-between gap-2">
                          <p className="text-sm text-fog">{membership.planName}</p>
                          <MembershipBadge
                            state={membership.derived.state}
                            label={stateLabels[membership.derived.state]}
                          />
                        </div>
                        <p className="mt-1 font-mono text-[0.625rem] text-ash">
                          {formatDate(membership.startDate)} → {formatDate(membership.endDate)}
                        </p>
                        <p className="mt-0.5 text-[0.625rem] text-ash/70">{formatINR(membership.pricePaise)} paid</p>
                      </li>
                    ))}
                </ul>
              ) : (
                <p className="mt-3 text-sm text-ash">No memberships on record.</p>
              )}
            </div>

            <div className="rounded-xl border border-white/10 bg-coal p-4">
              <h2 className="eyebrow">Need help?</h2>
              <p className="mt-2 text-xs leading-relaxed text-ash">
                Quote your payment reference when contacting the front desk about a payment.
              </p>
              <Link href="/contact" className="mt-3 inline-flex items-center gap-1 text-xs font-medium text-fog hover:text-signal">
                Contact the gym <ArrowUpRight size={12} aria-hidden="true" />
              </Link>
            </div>

            {payments.some((payment) => payment.status === "review") ? (
              <div className="rounded-xl border border-amber-300/30 bg-amber-300/10 p-4">
                <p className="text-xs font-medium text-amber-100">One payment needs review</p>
                <p className="mt-1 text-[0.6875rem] leading-relaxed text-amber-100/80">
                  A payment attempt did not match its order. Our team reviews these manually — no membership
                  is activated automatically.
                </p>
                {payments
                  .filter((payment) => payment.status === "review")
                  .map((payment) => (
                    <p key={payment._id.toString()} className="mt-2">
                      <PaymentBadge tone={paymentStatusMeta.review.tone}>
                        {paymentStatusMeta.review.label}
                      </PaymentBadge>
                    </p>
                  ))}
              </div>
            ) : null}
          </aside>
        </div>
      </div>
    </section>
  );
}
